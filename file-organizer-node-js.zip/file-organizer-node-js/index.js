import fs from "fs/promises";
import fsn from "fs";
import path from "path";

let basePath = "//media//HDD2Volume//recovery2//recovery//";
let files = await fs.readdir(basePath);

for (const item of files) {
    let fullPath = path.join(basePath, item);

    // Skip directories (only process files)
    if ((await fs.lstat(fullPath)).isDirectory()) continue;

    console.log("running for", item);

    let parts = item.split(".");
    let ext = parts.length > 1 ? parts.pop() : "";

    // Skip js and json files
    if (ext === "js" || ext === "json") continue;

    let targetFolder = "";

    if (!ext) {
        // No extension
        targetFolder = "no-ext-files";
    } else if (/^\d+$/.test(ext)) {
        // Extension is only numbers
        targetFolder = "number-ext-files";
    } else {
        // Normal extension
        targetFolder = ext;
    }

    // Create target folder path
    let targetPath = path.join(basePath, targetFolder);

    // Check if targetPath exists
    if (fsn.existsSync(targetPath)) {
        let stat = await fs.lstat(targetPath);
        if (!stat.isDirectory()) {
            // If it's a file, rename target folder
            targetPath = path.join(basePath, targetFolder + "_folder");
        }
    }

    // Create target folder if it doesn't exist
    if (!fsn.existsSync(targetPath)) {
        await fs.mkdir(targetPath);
    }

    // Move file
    await fs.rename(fullPath, path.join(targetPath, item));
}
