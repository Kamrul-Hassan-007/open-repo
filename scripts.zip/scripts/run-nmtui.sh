#~/.local/bin/run-nmtui.sh

exec nmtui
