#!/bin/bash

if ip a show CloudflareWARP | grep -q "inet "; then
  echo '{"text": " WARP", "tooltip": "Cloudflare WARP VPN is active"}'
else
  echo '{"text": " VPN OFF", "tooltip": "Cloudflare WARP VPN is not active"}'
fi

